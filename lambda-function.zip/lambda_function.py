import json
import boto3
import requests

region_name = 'ap-southeast-1'

def lambda_handler(event, context):
    lambda_client = boto3.client('lambda',region_name=region_name)
    s3 = boto3.client('s3')
    function_name = 'second-function-x86'
    bucket_name = 'bucketdemow2'
    
    # Get the existing function's code location
    existing_code = lambda_client.get_function(FunctionName=function_name)['Code']['Location']
    #print(existing_code)

    response = requests.get(existing_code)
    content = response.content

    file_name = 'second-function-x86-652f9916-d7e8-4cc8-86b8-0a8208fd7461.zip'
    s3.put_object(Body=content, Bucket=bucket_name, Key=file_name)
    print(f'Code Successfully uploaded to {bucket_name}!')
    
    '''
    # Construct the S3 bucket and key for the new code package
    source_code = {
        #'S3Bucket': existing_code.split('/')[2],
        #'S3Bucket': "singapur-bucket",
        #'S3Key': '/'.join(existing_code.split('/')[3:])
        #'S3Key': '/'.join(existing_code.split('/')[5:]).split('?')[0]
    }
    print(source_code)
    '''
    # Update the function's code and architecture
    lambda_client.update_function_code(
        FunctionName=function_name,
        Architectures=['arm64'],
        S3Bucket=bucket_name,
        S3Key=file_name
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

